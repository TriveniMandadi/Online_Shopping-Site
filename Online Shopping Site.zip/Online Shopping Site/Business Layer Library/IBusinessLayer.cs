﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OnlineShoppingEntityLib; // For entities in OnlineShoppingEntityLib

namespace OnlineShoppingBusinessLayerLib 
{
    /// <summary>
    /// Interface for online shopping Business layer
    /// </summary>
    public interface IBusinessLayer
    {
        /// <summary>
        /// This method will display/retrieve all the categories in the home page 
        /// </summary>
        /// <returns>List of categories from database</returns>
        List<Home> GetAllCategoriesList();

        /// <summary>
        /// This method will retrieve the products present in category when clicked on categoryname
        /// </summary>
        /// <param name="categoryName">Names of categories are passed</param>
        /// <returns>It returns the products list present in selected category</returns>
        List<Products> GetProductsByCategory(string categoryName);

        /// <summary>
        /// This method will retrieve the products based on the name of the product given by user
        /// </summary>
        /// <param name="productName">Names of products are passed</param>
        /// <returns>returns the products with the searched product</returns>
        List<Products> GetProductsByProductName(string productName);

        /// <summary>
        /// This method retrieves the complete details of the product based on the id 
        /// </summary>
        /// <param name="productId">procuct id is passed</param>
        /// <returns>Returns single product based on id</returns>
        ProductDetails GetDetailsOfProductByProductId(int productId);

        /// <summary>
        /// This method will add the products to the cart when clicked on add to cart button
        /// and returns to the home page
        /// </summary>
        /// <param name="cartItems">cartitems list is passed</param>
        void AddToCart(List<CartItems> cartItems);

        /// <summary>
        /// This method displays all the details of products present in the cart when clicked 
        /// on cart item in home page
        /// </summary>
        /// <returns>returns added cart items</returns>
        List<CartItems> GetCartDetails();      

        /// <summary>
        /// This method adds the cart items to the ddatabase 
        /// </summary>
        /// <param name="cartItems"></param>
        void PostToCart(CartItems cartItems);

        /// <summary>
        /// This method will cancel the order that are previously buyed by the user
        /// </summary>
        /// <param name="productId">Product Id is passed as an parameter</param>
        void DeleteItemFromCart(int productId);

        /// <summary>
        /// This method will retrieve the user name that is stored in the database
        /// </summary>
        /// <param name="userName">User name is passed as parameter</param>
        /// <returns>Returns the user name</returns>
        LoginDetails GetUserName(string userName);

        /// <summary>
        /// This method will retrieve the password that is stored in the database
        /// </summary>
        /// <param name="password">password is passed as an parameter</param>
        /// <returns>Returns the password that is stored in the database</returns>
        LoginDetails GetPassword(string password);        
    }
}