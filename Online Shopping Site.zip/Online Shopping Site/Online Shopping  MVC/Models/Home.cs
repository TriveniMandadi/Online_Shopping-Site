﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace OnlineShoppingMvc.Models
{
    /// <summary>
    /// Home class (Home page)
    /// </summary>
    public class Home
    {
        /// <summary>
        /// Category Id
        /// </summary>
        public int CategoryId { get; set; }

        /// <summary>
        /// Category Name(Name of category)
        /// </summary>
        public string CategoryName { get; set; }
    }
}