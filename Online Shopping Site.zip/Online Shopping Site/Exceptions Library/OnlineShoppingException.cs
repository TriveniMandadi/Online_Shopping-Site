﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OnlineShoppingExceptionLib
{
    /// <summary>
    /// OnlineShoppingExceptionClass 
    /// </summary>
    public class OnlineShoppingException : Exception //extending exception class
    {
        public OnlineShoppingException(string errMsg) : base(errMsg)
        {
            //TODO log the error in file or elsewhere
        }
    }
}
