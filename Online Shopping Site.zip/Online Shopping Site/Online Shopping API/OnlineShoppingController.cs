﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using OnlineShoppingEntityLib;  // For entities in OnlineShoppingEntityLib
using OnlineShoppingBusinessLayerLib;//For OnlineShoppingBusinessLib
using OnlineShoppingExceptionLib;   //For user defined exception library
namespace OnlineShoppingAPI.Controllers
{
    /// <summary>
    /// OnlineShoppingController class for web API
    /// </summary>
    public class OnlineShoppingController : ApiController
    {
        /// <summary>
        /// This method retrieves all the categories that are present in the database and
        /// displays that in home page so that user can know what are the categories in it
        /// </summary>
        /// <returns> This method returns the list of categories</returns>        
        public HttpResponseMessage Get()
        {
            //HttpResponseMessage works with HTTP protocol to return the data with status/error
            HttpResponseMessage httpResponseMessage = Request.CreateResponse(HttpStatusCode.OK);
            //try block incase if code throws an exception
            try
            {
                //Creating object for business layer class
                OlShoppingBusinessLayer bll = new OlShoppingBusinessLayer();
                //It retrieves list of categories from businesslayer and storing it in variable
                var clst = bll.GetAllCategoriesList();
                //It will creates the response and has the list of products
                httpResponseMessage = Request.CreateResponse<List<Home>>(HttpStatusCode.OK, clst);
            }
            //If OnlineShoppingException occurs it will be handled here
            catch (OnlineShoppingException e)
            {
                //returns the status
                httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.NotFound, e.Message);
            }
            //If any other exceptions that are not handled in previous catch block, it will be handled here
            catch (Exception e)
            {
                //returns the response status
                httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.NotFound, e.Message);
            }
            //Returns the response message status
            return httpResponseMessage;
        }

        /// <summary>
        /// This method retrieves the products when user clicked on the category names
        /// </summary>
        /// <param name="name"> name (category name) is passed</param>
        /// <returns>Returns the product or list of products according to category user selects</returns>
        [Route("api/OnlineShopping/GetProductsByCategory/{name}")]
        public HttpResponseMessage Get(string name)
        {
            //HttpResponseMessage works with HTTP protocol to return the data with status/error
            HttpResponseMessage httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.OK, "Products in categories was found");
            //try block incase if code throws an exception
            try
            {
                //creating instance for business layer
                OlShoppingBusinessLayer bll = new OlShoppingBusinessLayer();
                //It contains all the products when user selects category and stores in variable
                var clst = bll.GetProductsByCategory(name);
                //It will creates the response and has the list of products
                httpResponseMessage = Request.CreateResponse<List<Products>>(clst);
            }
            //If OnlineShoppingException occurs it will be handled here
            catch (OnlineShoppingException e)
            {
                //if the product does not exist it will return the status
                httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.NotFound, e.Message);
            }
            //If any other exceptions that are not handled in previous catch block, it will be handled here
            catch (Exception e)
            {
                //if the product does not exist it will return the status
                httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.NotFound, e.Message);
            }
            //Returns the response message status
            return httpResponseMessage;
        }

        /// <summary>
        /// This method retrieves the products based on the product name search by user
        /// </summary>
        /// <param name="name"> name (product name) is passed</param>
        /// <returns>Returns the product or list of products according to the name given by user</returns>
        [Route("api/OnlineShopping/GetProductsByProductName/{name}")]        
        public HttpResponseMessage GetByName(string name)
        {
            //HttpResponseMessage works with HTTP protocol to return the data with status/error
            HttpResponseMessage httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.OK, "List of Products was found");
            //try block incase if code throws an exception
            try
            {
                //creating instance for business layer
                OlShoppingBusinessLayer bll = new OlShoppingBusinessLayer();
                //It contains all the products when searched it with product name and stores in variable
                var productsList = bll.GetProductsByProductName(name);
                //It will creates the response and has the list of products
                httpResponseMessage = Request.CreateResponse<List<Products>>(productsList);
            }
            //If OnlineShoppingException occurs it will be handled here
            catch(OnlineShoppingException e)
            {
                //if the product does not exist it will return the status 
                httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.NotFound, e.Message);
            }
            //If any other exceptions that are not handled in previous catch block, it will be handled here
            catch(Exception e)
            {
                //if the product does not exist it will return the status
                httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.NotFound, e.Message);
            }
            //Returns the response message status
            return httpResponseMessage;
        }        

        /// <summary>
        /// This method displays the entire details of the product based on id of product
        /// </summary>
        /// <param name="id">product id is passed as parameter</param>
        /// <returns> Returns the details of product </returns>
        public HttpResponseMessage Get(int id)
        {
            //HttpResponseMessage works with HTTP protocol to return the data with status/error
            HttpResponseMessage httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.OK, "Product by Id was found");
            //try block incase if code throws an exception
            try
            {
                //creates object for business layer
                OlShoppingBusinessLayer bll = new OlShoppingBusinessLayer();
                //details of product based on id is stored in another variable
                var details = bll.GetDetailsOfProductByProductId(id);
                //creates the response and returns the details of product
                httpResponseMessage = Request.CreateResponse<ProductDetails>(details);
            }
            //If OnlineShoppingException occurs it will be handled here
            catch (OnlineShoppingException e)
            {
                //if the product does not exist it will return the status
                httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.NotFound,e.Message);
            }
            //If any other exceptions that are not handled in previous catch block, it will be handled here
            catch (Exception e)
            {
                //if the product does not exist it will return the status 
                httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.NotFound,e.Message);
            }
            //returns httpResponse message
            return httpResponseMessage;
        }

        /// <summary>
        /// This method adds the cart items to the cart
        /// </summary>
        /// <param name="cartItems"></param>
        /// <returns>returns the items present in the cart</returns>
        public HttpResponseMessage Post([FromBody] List<CartItems> cartItems)
        {
            //HttpResponseMessage works with HTTP protocol to return the data with status/error
            HttpResponseMessage httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.OK, "products added to cart");
            //try block incase if code throws an exception
            try
            {
                //creates object for business layer
                OlShoppingBusinessLayer bll = new OlShoppingBusinessLayer();
                //adding items to cart
                bll.AddToCart(cartItems);
            }
            //If OnlineShoppingException occurs it will be handled here
            catch (OnlineShoppingException e)
            {
                //if the product does not exist it will return the status
                httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.BadRequest, e.Message);
            }
            //If any other exceptions that are not handled in previous catch block, it will be handled here
            catch (Exception e)
            {
                //if the product does not exist it will return the status 
                httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.NotFound,e.Message);
            }
            //returns httpresponse message
            return httpResponseMessage;
        }

        /// <summary>
        /// This method displays the items present in the cart
        /// </summary>
        /// <returns>returns items present in cary</returns>
        [Route("api/OnlineShopping/GetProductsFromCart")]      
        public HttpResponseMessage GetCartItems()
        {
            //HttpResponseMessage works with HTTP protocol to return the data with status/error
            HttpResponseMessage httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.OK, "Cart Items");
            //try block incase if code throws an exception
            try
            {
                //creates object for business layer
                OlShoppingBusinessLayer bll = new OlShoppingBusinessLayer();
                //items in cart is stored to cartProducts variable
                var cartProducts = bll.GetCartDetails();
                //It will creates the response and has the list of products
                httpResponseMessage = Request.CreateResponse<List<CartItems>>(HttpStatusCode.OK, cartProducts);
            }
            //If OnlineShoppingException occurs it will be handled here
            catch (OnlineShoppingException e)
            {
                //if the product does not exist it will return the status
                httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.BadRequest, e.Message);
            }
            //If any other exceptions that are not handled in previous catch block, it will be handled here
            catch (Exception e)
            {
                //if the product does not exist it will return the status
                httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.NotFound, e.Message);
            }
            //returns httpresponse message
            return httpResponseMessage;
        }        

        /// <summary>
        /// This method adds the cart items to database
        /// </summary>
        /// <param name="c">sends the cartitems as parameter</param>
        [Route("api/OnlineShopping/PostToCart")]
        public HttpResponseMessage PostToCart([FromBody] CartItems c)
        {
            //HttpResponseMessage works with HTTP protocol to return the data with status/error
            HttpResponseMessage httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.OK, "cart products added to database");
            //try block incase if code throws an exception
            try
            {
                //creates object for business layer
                OlShoppingBusinessLayer bll = new OlShoppingBusinessLayer();
                //adding items to cart
                bll.PostToCart(c);
            }
            //If OnlineShoppingException occurs it will be handled here
            catch (OnlineShoppingException e)
            {
                //if the product does not exist it will return the status
                httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.BadRequest, e.Message);
            }
            //If any other exceptions that are not handled in previous catch block, it will be handled here
            catch (Exception e)
            {
                //if the product does not exist it will return the status
                httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.NotFound, e.Message);
            }
            //returns httpresponse message
            return httpResponseMessage;
        }

        /// <summary>
        /// This method removes the item from the cart
        /// </summary>
        /// <param name="productId">Deletion from cart is done based on id of product</param>
        /// <returns>The products in cart after deletion</returns>
        [Route("api/OnlineShopping/DeleteProductFromPlacingOrder/{productId}")]
        public HttpResponseMessage DeleteItemFromCart(int productId)
        {
            //HttpResponseMessage works with HTTP protocol to return the data with status/error
            HttpResponseMessage httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.OK, "Item deleted");
            //try block incase if code throws an exception
            try
            {
                //creates object for business layer
                OlShoppingBusinessLayer bll = new OlShoppingBusinessLayer();
                //deletion from cart by id
                bll.DeleteItemFromCart(productId);
            }
            //If OnlineShoppingException occurs it will be handled here
            catch (OnlineShoppingException ex)
            {
                //if the product does not exist it will return the status 
                httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.NotFound, ex.Message);
            }
            //If any other exceptions that are not handled in previous catch block, it will be handled here
            catch (Exception e)
            {
                //if the product does not exist it will return the status 
                httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.NotFound, e.Message);
            }
            //returns http response message
            return httpResponseMessage;
        }        
    }
}
     